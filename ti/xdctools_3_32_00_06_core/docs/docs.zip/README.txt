About the docs directory
========================

The documents in this directory can be viewed several ways:
 -- online at http://rtsc.eclipse.org/docs-tip
 -- using the "xdctools.chm" Microsoft HTML Help file on Windows
 -- using the Eclipse Help viewer after installing the
    "RTSC/XDCtools (IDE Support)" feature
 -- unzipping the "docs.zip" file and viewing with any web browser

To unzip the "docs.zip" file, use any .zip file handler program to expand
it directly into the docs directory. The docs can then be accessed via the
"index.html" file.

Note: Don't move, remove, or rename the "docs.zip" file itself, since
Eclipse Help displays its content directly from this file.
